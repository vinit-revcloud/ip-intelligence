"""The live lookup path.

    IP -> GET /lookup/{ip}
       -> unified.ip_geo             -> geo answers, if any
       -> unified.ip_intelligence    -> proxy answers, if any
       -> proxy miss? -> proxycheck.io -> return it, and append the row back

The append is what makes this a cache rather than a passthrough: the next
lookup of the same IP finds it in ip_intelligence and costs no quota. That is
why proxycheck is no longer one of the compared vendors in that table. It is
the miss path, and the only rows it writes are ones that arrived through it.

The append is fired without waiting. An Athena INSERT takes a couple of
seconds and the caller should not pay for a write they did not ask for. The
row is visible to the next lookup a moment later.

What counts as a hit:
  geo    at least one vendor returned a state, a city or a coordinate.
  proxy  at least one vendor actually answered, meaning is_proxy is not NULL.
         A row of all-NULLs means the spine has an entry for this IP but no
         vendor had an opinion, which is a miss, not a clean verdict.
"""
import json
import os
import time
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor

import boto3

athena = boto3.client("athena")
_sm = boto3.client("secretsmanager")

WORKGROUP = "ipintel"
DB = "unified"
LIVE = "ipintel_curated.pc_live"
PC_SECRET = os.environ.get("PROXYCHECK_SECRET", "ipintel/proxycheck")
PC_TIMEOUT_S = 8
POLL_BUDGET_S = 25

_key_cache = {}

GEO_COLS = ["vendor", "state", "city", "zip_code", "latitude", "longitude", "timezone",
            "created_at", "updated_at"]
INTEL_COLS = ["vendor", "is_proxy", "is_vpn", "is_tor", "is_datacenter", "is_bot",
              "is_compromised", "is_scraper", "is_anonymous", "isp", "asn",
              "created_at", "updated_at"]


def _lit(v):
    return "'" + str(v).replace("'", "''") + "'"


def _cast(value, kind):
    """Athena returns text. Rebuild real types, and keep NULL as None.

    The booleans are tri-state. Collapsing NULL to false would turn "no vendor
    answered" into "every vendor said no", which is the opposite claim.
    """
    if value is None:
        return None
    k = kind.lower()
    if k == "boolean":
        return value == "true"
    if k in ("tinyint", "smallint", "integer", "int", "bigint"):
        return int(value)
    if k in ("float", "real", "double", "decimal"):
        return float(value)
    return value


def _run(sql, wait=True):
    qid = athena.start_query_execution(QueryString=sql, WorkGroup=WORKGROUP)["QueryExecutionId"]
    if not wait:
        return qid, None
    deadline = time.time() + POLL_BUDGET_S
    delay = 0.12
    while time.time() < deadline:
        ex = athena.get_query_execution(QueryExecutionId=qid)["QueryExecution"]
        st = ex["Status"]["State"]
        if st == "SUCCEEDED":
            return qid, athena.get_query_results(QueryExecutionId=qid, MaxResults=100)
        if st in ("FAILED", "CANCELLED"):
            raise RuntimeError(ex["Status"].get("StateChangeReason", st))
        time.sleep(delay)
        delay = min(delay * 1.5, 1.0)
    raise TimeoutError(qid)


def _rows(result):
    meta = result["ResultSet"]["ResultSetMetadata"]["ColumnInfo"]
    names = [c["Name"] for c in meta]
    kinds = [c["Type"] for c in meta]
    out = []
    for r in result["ResultSet"]["Rows"][1:]:          # first row is the header
        data = r.get("Data", [])
        out.append({n: _cast((data[i] if i < len(data) else {}).get("VarCharValue"), kinds[i])
                    for i, n in enumerate(names)})
    return out


def _dedupe(rows):
    """One row per vendor, keeping the most recently updated."""
    best = {}
    for r in rows:
        v = r.get("vendor")
        if v not in best or (r.get("updated_at") or "") > (best[v].get("updated_at") or ""):
            best[v] = r
    return [best[k] for k in sorted(best)]


def _select_geo(ip):
    return (f"SELECT {', '.join(GEO_COLS)} FROM {DB}.ip_geo "
            f"WHERE ip_address = {_lit(ip)} ORDER BY vendor")


def _select_intel(ip):
    """The bulk table plus the live one, in a single scan.

    unified.ip_intelligence is bucketed on ip_address, which is what keeps a
    point lookup at ~3 MB instead of ~200 MB. Athena refuses INSERT on a
    bucketed table, so rows fetched on the miss path land in the unbucketed
    pc_live instead and are read alongside. The next rebuild folds pc_live back
    into the bulk table.
    """
    live_cols = [c for c in INTEL_COLS if c != "vendor"]
    return (f"SELECT {', '.join(INTEL_COLS)} FROM {DB}.ip_intelligence "
            f"WHERE ip_address = {_lit(ip)} "
            f"UNION ALL "
            f"SELECT 'proxycheck_io', {', '.join(live_cols)} FROM {LIVE} "
            f"WHERE ip_address = {_lit(ip)} "
            f"ORDER BY vendor")


def _pc_key():
    if "k" not in _key_cache:
        _key_cache["k"] = _sm.get_secret_value(SecretId=PC_SECRET)["SecretString"].strip()
    return _key_cache["k"]


def _proxycheck(ip):
    """One live lookup.

    The flags are not optional. vpn=3 is the only setting where proxy and VPN
    come back as separate answers; under vpn=1 a proxy result overwrites the VPN
    result and is_proxy and is_vpn would contradict each other. seen=1 is the
    only way `last seen unix` is returned, and that is what updated_at maps to.
    """
    url = ("https://proxycheck.io/v2/?key=" + urllib.parse.quote(_pc_key())
           + "&vpn=3&asn=1&risk=1&seen=1&days=90")
    body = urllib.parse.urlencode({"ips": ip}).encode()
    req = urllib.request.Request(url, data=body, headers={"User-Agent": "ipintel-lookup/1.0"})
    d = json.loads(urllib.request.urlopen(req, timeout=PC_TIMEOUT_S).read())
    # "warning" still carries the full record - it is how proxycheck reports
    # things like being within 10% of the daily limit. Treating it as a failure
    # would throw away an answer already paid for, so only a denial is fatal.
    if d.get("status") not in ("ok", "warning"):
        raise RuntimeError(d.get("message") or f"proxycheck status {d.get('status')}")
    v = d.get(ip)
    if not isinstance(v, dict):
        raise RuntimeError(d.get("message") or "proxycheck returned no record for this address")
    return v, (d.get("message") if d.get("status") == "warning" else None)


def _normalise(ip, raw):
    """proxycheck's response mapped onto the ip_intelligence columns."""
    t = (raw.get("type") or "").strip()
    tl = t.lower()
    proxy = raw.get("proxy") == "yes"
    vpn = raw.get("vpn") == "yes"
    anon = (raw.get("operator") or {}).get("anonymity")
    now = time.strftime("%Y-%m-%dT%H:%M:%SZ")
    seen = raw.get("last seen unix")
    updated = (time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(int(seen))) if seen else now)
    return {
        "ip_address": ip, "vendor": "proxycheck_io",
        "is_proxy": proxy, "is_vpn": vpn, "is_tor": tl == "tor",
        "is_datacenter": tl in ("hosting", "business"),
        "is_bot": None,                              # proxycheck does not classify bots
        "is_compromised": tl == "compromised server",
        "is_scraper": tl == "scraper",
        "is_anonymous": bool(anon) or proxy or vpn,
        "isp": raw.get("provider") or None, "asn": raw.get("asn") or None,
        "created_at": now, "updated_at": updated,
    }


def _b(v):
    return "NULL" if v is None else ("true" if v else "false")


def _s(v):
    return "NULL" if v is None else _lit(v)


def _append(row):
    """Write the new row into ip_intelligence. Fired and not awaited.

    Each insert lands as its own small Parquet file. At the measured rate of
    roughly 850 genuinely new IPs a day that is 850 files a day, so the table
    needs a periodic compaction. It is not urgent and it is not this path's job.
    """
    sql = (f"INSERT INTO {LIVE} SELECT "
           f"{_lit(row['ip_address'])}, "
           f"{_b(row['is_proxy'])}, {_b(row['is_vpn'])}, {_b(row['is_tor'])}, "
           f"{_b(row['is_datacenter'])}, {_b(row['is_bot'])}, {_b(row['is_compromised'])}, "
           f"{_b(row['is_scraper'])}, {_b(row['is_anonymous'])}, "
           f"{_s(row['isp'])}, {_s(row['asn'])}, "
           f"{_lit(row['created_at'])}, {_lit(row['updated_at'])}")
    qid, _ = _run(sql, wait=False)
    return qid


def serve(ip, refresh=False):
    """Handle one /lookup/{ip}. Returns (status_code, body)."""
    t0 = time.time()
    try:
        with ThreadPoolExecutor(max_workers=2) as ex:
            fg = ex.submit(_run, _select_geo(ip))
            fi = ex.submit(_run, _select_intel(ip))
            geo_rows = _rows(fg.result()[1])
            intel_rows = _dedupe(_rows(fi.result()[1]))
    except TimeoutError:
        return 504, {"error": "lookup timed out", "ip": ip}
    except RuntimeError as e:
        return 502, {"error": "athena rejected the lookup", "detail": str(e)}

    geo_hit = any(r.get("state") or r.get("city") or r.get("latitude") is not None
                  for r in geo_rows)
    intel_answered = [r for r in intel_rows if r.get("is_proxy") is not None]

    out = {
        "ip": ip,
        "geo": {"found": geo_hit, "source": f"{DB}.ip_geo" if geo_hit else None,
                "vendors": len(geo_rows), "answers": geo_rows},
        "proxy": {"found": bool(intel_answered), "source": None,
                  "vendors": len(intel_rows), "answers": intel_rows},
        "elapsed_ms": int((time.time() - t0) * 1000),
    }

    if intel_answered and not refresh:
        out["proxy"]["source"] = f"{DB}.ip_intelligence"
        out["proxy"]["cache"] = "hit"
        return 200, out

    # Miss. This is the only condition under which quota is spent.
    try:
        raw, warning = _proxycheck(ip)
    except KeyError:
        return 503, {"error": f"no proxycheck credential at {PC_SECRET}", "ip": ip,
                     "partial": out}
    except Exception as e:
        out["proxy"]["source"] = "proxycheck.io"
        out["proxy"]["cache"] = "miss"
        out["proxy"]["error"] = f"{type(e).__name__}: {e}"
        return 502, out

    row = _normalise(ip, raw)
    out["proxy"] = {
        "found": True, "source": "proxycheck.io", "cache": "miss",
        "vendors": len(intel_rows) + 1,
        "answers": intel_rows + [{k: v for k, v in row.items() if k != "ip_address"}],
        "risk_score": raw.get("risk"), "fraud_reason": raw.get("type") or None,
    }
    if warning:
        # Surfaced, not swallowed: the team needs to see quota pressure before
        # the key is exhausted and every miss starts failing.
        out["proxy"]["vendor_warning"] = warning
    try:
        out["proxy"]["appended_query_id"] = _append(row)
        out["proxy"]["appended"] = True
    except Exception as e:
        # The answer is still correct; only the caching of it failed.
        out["proxy"]["appended"] = False
        out["proxy"]["append_error"] = f"{type(e).__name__}: {e}"

    # proxycheck returns location in the same response, so when geo also missed
    # there is no reason to throw it away. It is labelled by its own source and
    # is not written to ip_geo.
    if not geo_hit:
        out["geo"]["fallback"] = {
            "source": "proxycheck.io", "state": raw.get("region"), "city": raw.get("city"),
            "zip_code": raw.get("postcode"), "latitude": raw.get("latitude"),
            "longitude": raw.get("longitude"), "timezone": raw.get("timezone"),
        }

    out["elapsed_ms"] = int((time.time() - t0) * 1000)
    return 200, out
