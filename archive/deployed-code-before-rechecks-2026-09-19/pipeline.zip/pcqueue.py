"""Addresses from the base tables that need proxycheck.io: ipintel_curated.proxycheck_queue.

The rule is the one the lookup API applies (lookup.needs_proxycheck), so an address gets the same treatment
whether it arrives through a new base-table row or a direct API call:

  Never, when proxycheck.io has already answered the address, or it is not a public address.
  Otherwise, in this order:
    new_address          the address was not in ip_geo / ip_intelligence before this run
    no_location          no vendor gave a location
    no_answer            no vendor gave a proxy answer
    vendors_disagree     proxy vendors disagree
    flagged_unconfirmed  flagged, with nothing confirming it
    location_disagree    location vendors disagree

Which addresses are checked: every address whose base-table rows changed since the previous successful run
(its ip_occurrences row was inserted or updated) plus every address IP2Location first answered since then.
The window starts at the previous run's watermark, so a failed run is covered again by the next one.

Job A queues them. Job B sends every waiting address first, the same day, and closes each queue row when the
answer is in the tables (or proxycheck.io had no record for it).
"""
from common import DB, lit, public_ipv4_sql, rows, run, scalar

QUEUE = DB + ".proxycheck_queue"
REASONS = ["new_address", "no_location", "no_answer", "vendors_disagree", "flagged_unconfirmed",
           "location_disagree"]


def reason_sql(r, is_new):
    """Why the resolved row `r` needs proxycheck.io, or NULL. Mirrors lookup.needs_proxycheck."""
    return f"""CASE WHEN {r}.proxy_decided_by = 'proxycheck_io' THEN NULL
       WHEN NOT ({public_ipv4_sql(r + '.ip_address')}) THEN NULL
       WHEN {is_new} THEN 'new_address'
       WHEN {r}.geo_status = 'no_answer' THEN 'no_location'
       WHEN {r}.proxy_status IN ('no_answer', 'vendors_disagree', 'flagged_unconfirmed') THEN {r}.proxy_status
       WHEN {r}.geo_status = 'vendors_disagree' THEN 'location_disagree'
  END"""


def candidates_sql(since):
    return f"""
WITH new AS (
  SELECT ip_address FROM {DB}.ip_geo WHERE vendor = 'ip2location_db11' AND created_at >= {lit(since)}),
touched AS (
  SELECT ip_address FROM {DB}.ip_occurrences WHERE updated_at >= {lit(since)}
  UNION SELECT ip_address FROM new)
SELECT r.ip_address, {reason_sql('r', 'n.ip_address IS NOT NULL')} AS reason
FROM touched t
JOIN {DB}.ip_resolved r ON r.ip_address = t.ip_address
LEFT JOIN new n ON n.ip_address = t.ip_address"""


def enqueue(staging, since, queued_at, run_id):
    """Add every base-table address that needs proxycheck.io. Returns (counts by reason, check)."""
    stg = staging.ctas("pc_candidates", "SELECT * FROM (%s) WHERE reason IS NOT NULL" % candidates_sql(since))
    by_reason = {r["reason"]: r["n"] for r in rows("SELECT reason, count(*) AS n FROM %s GROUP BY reason" % stg)}
    if by_reason:
        run(f"""
MERGE INTO {QUEUE} t USING {stg} s ON t.ip_address = s.ip_address
WHEN NOT MATCHED THEN INSERT (ip_address, reason, source, queued_at, queued_by_run, answered_at, outcome)
  VALUES (s.ip_address, s.reason, 'base_tables', {lit(queued_at)}, {lit(run_id)}, CAST(NULL AS varchar), CAST(NULL AS varchar))""")
    missing = scalar(f"SELECT count(*) FROM {stg} s LEFT JOIN {QUEUE} q ON q.ip_address = s.ip_address WHERE q.ip_address IS NULL")
    check = {"name": "Every base-table address that needs proxycheck.io is queued", "passed": not missing,
             "detail": None if not missing else "%d addresses needing proxycheck.io are not in the queue" % missing}
    return by_reason, check


def waiting_sql():
    """Queued addresses still without a proxycheck.io answer."""
    return f"""SELECT q.ip_address FROM {QUEUE} q
WHERE q.answered_at IS NULL
  AND NOT EXISTS (SELECT 1 FROM {DB}.ip_intelligence i WHERE i.ip_address = q.ip_address AND i.vendor = 'proxycheck_io')"""


def close(staging, closed_at, no_record_ips):
    """Mark queue rows answered once proxycheck.io's answer is in ip_intelligence, and rows proxycheck.io
    returned no record for. Returns how many are still waiting."""
    run(f"""
MERGE INTO {QUEUE} t
USING (SELECT DISTINCT ip_address FROM {DB}.ip_intelligence WHERE vendor = 'proxycheck_io') s
ON t.ip_address = s.ip_address
WHEN MATCHED AND t.answered_at IS NULL THEN UPDATE SET answered_at = {lit(closed_at)}, outcome = 'answered'""")
    if no_record_ips:
        staging.put_ndjson("no_record", [{"ip_address": ip} for ip in no_record_ips])
        nr = staging.json_table("no_record", "ip_address string")
        run(f"""
MERGE INTO {QUEUE} t USING (SELECT DISTINCT ip_address FROM {nr}) s ON t.ip_address = s.ip_address
WHEN MATCHED AND t.answered_at IS NULL THEN UPDATE SET answered_at = {lit(closed_at)}, outcome = 'no_record_from_proxycheck'""")
    return scalar("SELECT count(*) FROM %s WHERE answered_at IS NULL" % QUEUE)
