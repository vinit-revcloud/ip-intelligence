"""Publish the enriched tables to the two unified tables other teams' APIs read.

unified.ip_geo and unified.ip_intelligence were created by this project on 11 September. Their data
files live in this project's own S3 folder (ip-intelligence/unified/<table>/d=2026-09-11/), so they can
be refreshed without any change to the Glue catalog: the table definition, columns, bucketing and
location stay exactly as they are, and only the parquet files inside that folder are replaced.

Order of work, per table. Nothing in unified changes until every check on the new copy has passed.
  1. The unified table still has the definition this code expects. Otherwise stop.
  2. The 11 September files are copied once to archive/ and never removed.
  3. A bucketed copy of ipintel_curated.<table> is written to a staging folder (same 64 buckets on
     ip_address, same parquet format as the original).
  4. The copy is checked: row count, no duplicate (ip_address, vendor), 64 bucket files, and point
     lookups for sample addresses answer the same as the curated table.
  5. The current files are copied to publish-previous/ (the rollback copy), then the new files are
     copied in, then the old files are removed. Readers see old + new rows for a few seconds, never
     an empty table.
  6. unified.<table> is checked the same way. On any failure the previous files are put back.
"""
import json
import re
import traceback

import common as c

TABLES = ["ip_geo", "ip_intelligence"]
UNIFIED_DB = "unified"
LIVE_DIR = {t: "%s/unified/%s/d=2026-09-11/" % (c.PREFIX, t) for t in TABLES}
ARCHIVE_DIR = {t: "%s/archive/unified-2026-09-11/%s/" % (c.PREFIX, t) for t in TABLES}
PREVIOUS_DIR = {t: "%s/publish-previous/%s/" % (c.PREFIX, t) for t in TABLES}
BUCKETS = 64
_BUCKET_FILE = re.compile(r"^(\d{6})_")


def _keys(prefix):
    out, token = [], None
    while True:
        kw = {"Bucket": c.BUCKET, "Prefix": prefix}
        if token:
            kw["ContinuationToken"] = token
        page = c.s3.list_objects_v2(**kw)
        out += [o["Key"] for o in page.get("Contents", []) if not o["Key"].endswith("/")]
        if not page.get("IsTruncated"):
            return out
        token = page["NextContinuationToken"]


def _copy(keys, src_prefix, dst_prefix):
    for k in keys:
        c.s3.copy_object(Bucket=c.BUCKET, Key=dst_prefix + k[len(src_prefix):],
                         CopySource={"Bucket": c.BUCKET, "Key": k})


def _delete(keys):
    for i in range(0, len(keys), 1000):
        c.s3.delete_objects(Bucket=c.BUCKET, Delete={"Objects": [{"Key": k} for k in keys[i:i + 1000]], "Quiet": True})


def _columns(db, table):
    sd = c.glue.get_table(DatabaseName=db, Name=table)["Table"]["StorageDescriptor"]
    return [(x["Name"], x["Type"]) for x in sd["Columns"]], sd


def _guard(table):
    """The unified table must still be the one this project created; never write under anything else."""
    cols, sd = _columns(UNIFIED_DB, table)
    curated, _ = _columns(c.DB, table)
    problems = []
    if sd.get("Location", "").rstrip("/") != "s3://%s/%s" % (c.BUCKET, LIVE_DIR[table].rstrip("/")):
        problems.append("location is %s" % sd.get("Location"))
    if cols != curated:
        problems.append("columns differ from ipintel_curated.%s" % table)
    if sd.get("BucketColumns") != ["ip_address"] or sd.get("NumberOfBuckets") != BUCKETS:
        problems.append("bucketing is %s/%s" % (sd.get("BucketColumns"), sd.get("NumberOfBuckets")))
    if "parquet" not in (sd.get("SerdeInfo") or {}).get("SerializationLibrary", "").lower():
        problems.append("not parquet")
    return [n for n, _ in cols], problems


def _bucket_files_ok(keys):
    ids = set()
    for k in keys:
        m = _BUCKET_FILE.match(k.rsplit("/", 1)[-1])
        if not m:
            return False
        ids.add(int(m.group(1)))
    return ids <= set(range(BUCKETS)) and len(ids) >= BUCKETS - 1


def _profile(full_name, sample_ips):
    """Row count, duplicate count, and a fingerprint of the rows for sample addresses (read through the
    bucketed lookup path, the way an API querying one address reads it)."""
    counts = c.rows("SELECT count(*) AS n, count(*) - count(DISTINCT ip_address || '|' || vendor) AS dup FROM %s" % full_name)[0]
    in_list = ", ".join(c.lit(ip) for ip in sample_ips)
    fp = c.rows("SELECT ip_address, count(*) AS n, "
                "to_hex(md5(to_utf8(array_join(array_sort(array_agg(vendor || '|' || coalesce(updated_at, ''))), ',')))) AS h "
                "FROM %s WHERE ip_address IN (%s) GROUP BY ip_address" % (full_name, in_list))
    return counts["n"], counts["dup"], {r["ip_address"]: (r["n"], r["h"]) for r in fp}


def _samples(table):
    # Addresses spread over every bucket and every vendor, including the newest proxycheck answers.
    r = c.rows("SELECT ip_address FROM (SELECT ip_address, row_number() OVER (PARTITION BY vendor ORDER BY updated_at DESC) rn "
               "FROM %s.%s) WHERE rn <= 20 UNION SELECT ip_address FROM (SELECT ip_address FROM %s.%s "
               "TABLESAMPLE BERNOULLI (0.01) LIMIT 150)" % (c.DB, table, c.DB, table))
    return sorted({x["ip_address"] for x in r})[:300]


def publish_table(table, run_id, dry_run=False):
    cols, problems = _guard(table)
    if problems:
        raise RuntimeError("unified.%s is not in the expected shape, nothing written: %s" % (table, "; ".join(problems)))

    live_keys = _keys(LIVE_DIR[table])
    if not dry_run and not _keys(ARCHIVE_DIR[table]):          # first publish only: keep 11 September forever
        _copy(live_keys, LIVE_DIR[table], ARCHIVE_DIR[table])
        if len(_keys(ARCHIVE_DIR[table])) != len(live_keys):
            raise RuntimeError("the archive copy of unified.%s is incomplete; unified untouched" % table)

    staging = c.Staging(run_id + "-pub-" + table)
    try:
        name = staging.name("copy")
        loc = staging.location("copy")
        c.run("CREATE TABLE %s.%s WITH (format='PARQUET', write_compression='SNAPPY', bucketed_by=ARRAY['ip_address'], "
              "bucket_count=%d, external_location='%s') AS SELECT %s FROM %s.%s"
              % (c.DB, name, BUCKETS, loc, ", ".join(c.ident(x) for x in cols), c.DB, table), timeout_s=840)
        staging.names.append(name)
        new_prefix = loc[len("s3://%s/" % c.BUCKET):]
        new_keys = _keys(new_prefix)

        samples = _samples(table)
        cur_n, _, cur_fp = _profile("%s.%s" % (c.DB, table), samples)
        new_n, new_dup, new_fp = _profile("%s.%s" % (c.DB, name), samples)
        if new_n != cur_n or new_dup or new_fp != cur_fp or not _bucket_files_ok(new_keys):
            raise RuntimeError("the new copy of %s did not match ipintel_curated (rows %s vs %s, duplicates %s, "
                               "sample mismatch %s, bucket files ok %s); unified untouched"
                               % (table, new_n, cur_n, new_dup, new_fp != cur_fp, _bucket_files_ok(new_keys)))

        if dry_run:
            return {"table": "unified." + table, "rows": new_n, "files": len(new_keys), "samples_checked": len(samples),
                    "dry_run": True}
        c.delete_prefix(PREVIOUS_DIR[table])
        _copy(live_keys, LIVE_DIR[table], PREVIOUS_DIR[table])
        if len(_keys(PREVIOUS_DIR[table])) != len(live_keys):
            raise RuntimeError("the rollback copy of unified.%s is incomplete; unified untouched" % table)
        try:
            _copy(new_keys, new_prefix, LIVE_DIR[table])     # old + new rows visible for a few seconds
            _delete(live_keys)
            pub_n, pub_dup, pub_fp = _profile("%s.%s" % (UNIFIED_DB, table), samples)
            if pub_n != cur_n or pub_dup or pub_fp != cur_fp:
                raise RuntimeError("unified.%s did not read back correctly after the swap (rows %s vs %s, duplicates %s, "
                                   "sample mismatch %s)" % (table, pub_n, cur_n, pub_dup, pub_fp != cur_fp))
        except Exception as e:
            # Put the previous files back first, then remove anything else, so the table is never empty.
            _copy(_keys(PREVIOUS_DIR[table]), PREVIOUS_DIR[table], LIVE_DIR[table])
            _delete([k for k in _keys(LIVE_DIR[table]) if k not in set(live_keys)])
            raise RuntimeError("%s; the previous files were put back" % e)
        return {"table": "unified." + table, "rows": pub_n, "files": len(new_keys), "samples_checked": len(samples)}
    finally:
        staging.cleanup()


def handler(event, context):
    event = event or {}
    run_id = event.get("run_id") or c.new_run_id("publish-unified")
    log = c.start_run("publish-unified", run_id, {"trigger": event.get("trigger", "manual"),
                                                  "source_run": event.get("source_run")})
    done = []
    try:
        if c.is_paused()[0]:
            return c.finish_run(log, "skipped", "The pipeline is paused.")
        perm = c.permission_check()
        if not c.record_safety([perm]):
            return c.finish_run(log, "failed", "Safety check failed before any work was done: " + (perm["detail"] or ""))
        tables = [t for t in (event.get("tables") or TABLES) if t in TABLES]
        for t in tables:
            if context and context.get_remaining_time_in_millis() < 420000 and done:
                rest = [x for x in tables if x not in [d["table"].split(".")[1] for d in done]]
                c.lam.invoke(FunctionName=context.function_name, InvocationType="Event",
                             Payload=json.dumps({"action": "publish", "tables": rest, "trigger": "hand-over",
                                                 "source_run": event.get("source_run")}).encode())
                return c.finish_run(log, "succeeded", "Handed over %s to a fresh copy" % rest, published=done)
            done.append(publish_table(t, run_id, bool(event.get("dry_run"))))
        checks = [perm] + [{"name": "%s matches ipintel_curated" % d["table"], "passed": True,
                            "detail": "%d rows, %d bucket files, %d addresses compared" % (d["rows"], d["files"], d["samples_checked"])}
                           for d in done]
        if event.get("dry_run"):
            return c.finish_run(log, "succeeded", "Dry run: new copies built and checked; unified not changed",
                                published=done, checks=checks)
        c.update_item("publish", "unified", last_published_at=c.now_iso(), last_run_id=run_id, tables=done)
        return c.finish_run(log, "succeeded", None, published=done, checks=checks)
    except Exception as e:
        traceback.print_exc()
        return c.finish_run(log, "failed", "%s: %s" % (type(e).__name__, str(e)[:900]), published=done)
