"""Keeps the IP Intelligence app's report data current in S3, with no manual step.

After every successful full unified publish this module:
  1. rebuilds the day-to-day snapshot files (coverage, location accuracy, proxy coverage, both vendor scorecards);
  2. takes the one-time analysis files as they are (lead_ips, lead_ip_analysis, session_ip_labels), uploaded once
     to serving/app/static/;
  3. writes all nine, plus manifest.json, to s3://<bucket>/ip-intelligence/serving/app/.

The app reads them from there. Reads tables only; writes only under ip-intelligence/serving/app/.
"""
import common as c

APP = "%s/serving/app" % c.PREFIX
STATIC = ["lead_ips.json", "lead_ip_analysis.json", "session_ip_labels.json"]
ALL = STATIC + ["coverage.json", "geo_accuracy.json", "proxy_coverage.json",
                "vendor_overview_geo.json", "vendor_overview_proxy.json", "manifest.json"]


def build():
    """Return {name: object} for every file that can be built."""
    now = c.now_iso()
    files = {}
    for name in STATIC:
        key = "%s/static/%s" % (APP, name)
        if c.s3_exists(key):
            files[name] = c.s3_get_json(key)
    files["coverage.json"] = c.s3_get_json("%s/serving/%s/enrichment_coverage.json" % (c.PREFIX, c.DB))
    files["geo_accuracy.json"] = c.s3_get_json("%s/serving/%s/geo_accuracy.json" % (c.PREFIX, c.DB))
    cov = c.rows("""WITH ans AS (SELECT ip_address, count_if(is_proxy IS NOT NULL) n, count_if(vendor = 'proxycheck_io') pc
                                 FROM ipintel_curated.ip_intelligence GROUP BY 1)
                    SELECT count(*) AS addresses, count_if(n > 0) AS with_proxy_answer, count_if(pc > 0) AS with_proxycheck
                    FROM ans""")[0]
    files["proxy_coverage.json"] = dict({"as_of": now}, **cov)
    for t in ("vendor_overview_geo", "vendor_overview_proxy"):
        files[t + ".json"] = {"as_of": now, "table": "unified." + t,
                              "rows": c.rows("SELECT * FROM ipintel_curated.%s ORDER BY vendor" % t)}
    files["manifest.json"] = {"as_of": now, "files": sorted(files) + ["manifest.json"]}
    return files


def run(trigger="after-publish"):
    files = build()
    for name, obj in files.items():
        if name != "manifest.json":
            c.s3_put_json("%s/%s" % (APP, name), obj)
    c.s3_put_json("%s/manifest.json" % APP, files["manifest.json"])   # last: marks a complete set
    missing = sorted(set(ALL) - set(files))
    result = {"at": c.now_iso(), "trigger": trigger, "files": sorted(files), "missing": missing,
              "status": "complete" if not missing else "missing " + ", ".join(missing)}
    c.update_item("app", "export", **result)
    if missing:
        c.alert("IP app snapshot incomplete", "Written to s3://%s/%s/ without: %s" % (c.BUCKET, APP, ", ".join(missing)))
    return result
